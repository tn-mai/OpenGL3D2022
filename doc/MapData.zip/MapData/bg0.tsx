<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="bg0" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="bg/bg0.png" width="512" height="512"/>
 <tile id="113" probability="0.2"/>
 <tile id="114" probability="0.2"/>
 <tile id="115" probability="0.1"/>
 <tile id="116" probability="0.1"/>
 <tile id="117" probability="0.01"/>
 <tile id="118" probability="0.01"/>
 <tile id="119" probability="0.002"/>
</tileset>
