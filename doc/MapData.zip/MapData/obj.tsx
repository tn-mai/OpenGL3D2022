<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="obj" tilewidth="256" tileheight="128" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="64" height="64" source="obj/enemy_m_0.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="obj/enemy_s_0.png"/>
 </tile>
 <tile id="2">
  <image width="48" height="48" source="obj/asteroid_m.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="48" source="obj/enemy_s_1.png"/>
 </tile>
 <tile id="4">
  <image width="256" height="128" source="obj/enemy_boss_0.png"/>
 </tile>
</tileset>
